// src/app/api/arrive/route.ts
// Guest self check-in. The organiser prints the event's check-in QR at the
// entrance; guests scan it with their phone and enter (or tap through from their
// email) their personal check-in code. Only works around the event date.
import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import prisma from "@/lib/prisma";
import { rateLimit, clientIp, MINUTE } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const HOUR = 60 * MINUTE;

export async function POST(req: Request) {
  try {
    const limited = rateLimit([{ key: `arrive:${clientIp(req)}`, limit: 15, windowMs: 10 * MINUTE }]);
    if (limited) return limited;

    const body = await req.json().catch(() => ({}));
    const slug = typeof body.slug === "string" ? body.slug : "";
    const code = typeof body.code === "string" ? body.code.trim().toUpperCase().replace(/\s+/g, "") : "";
    if (!slug || !code) return NextResponse.json({ status: "invalid", message: "Enter the check-in code from your card or email." }, { status: 400 });

    const event = await prisma.event.findFirst({
      where: { slug, isPublished: true },
      select: { id: true, date: true },
    });
    if (!event) return NextResponse.json({ status: "invalid", message: "Event not found." }, { status: 404 });

    // Event dates are stored as the day (midnight UTC). Open from the evening before until two days after.
    const start = event.date.getTime() - 12 * HOUR;
    const end = event.date.getTime() + 48 * HOUR;
    const now = Date.now();
    if (now < start) {
      return NextResponse.json({ status: "too_early", message: "Self check-in opens on the day of the event. See you then!" });
    }
    if (now > end) {
      return NextResponse.json({ status: "closed", message: "Check-in for this event has closed." });
    }

    const rsvp = await prisma.rsvp.findUnique({
      where: { uniqueCode: code },
      include: { guest: { include: { checkin: true } } },
    });
    if (!rsvp || rsvp.guest.eventId !== event.id) {
      return NextResponse.json({ status: "invalid", message: "That code isn't valid for this event. Check your card or confirmation email." });
    }
    if (rsvp.status !== "CONFIRMED") {
      return NextResponse.json({ status: "invalid", message: "This invitation hasn't been confirmed. Please see an usher." });
    }

    const guest = { name: rsvp.guest.name, seatNumber: rsvp.seatNumber ?? null };
    if (rsvp.guest.checkin) {
      return NextResponse.json({ status: "already_checked_in", message: "You're already checked in. Welcome!", guest });
    }

    try {
      await prisma.checkin.create({ data: { eventId: event.id, guestId: rsvp.guestId, checkedInBy: "self" } });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === "P2002") {
        return NextResponse.json({ status: "already_checked_in", message: "You're already checked in. Welcome!", guest });
      }
      throw e;
    }

    return NextResponse.json({ status: "success", message: "You're checked in. Welcome!", guest });
  } catch (err) {
    console.error("/api/arrive error:", err);
    return NextResponse.json({ status: "invalid", message: "Something went wrong. Please try again or see an usher." }, { status: 500 });
  }
}
