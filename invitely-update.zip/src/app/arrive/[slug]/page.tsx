// src/app/arrive/[slug]/page.tsx
// Where the event's check-in QR (printed at the entrance) leads. Guests check
// themselves in on their own phone with the code from their card or email.
"use client";

import { useEffect, useState, FormEvent } from "react";
import { useParams } from "next/navigation";
import { CheckCircle, XCircle, AlertCircle, Loader2, QrCode } from "lucide-react";
import type { PublicEvent } from "@/types";

type Result = {
  status: "success" | "already_checked_in" | "invalid" | "too_early" | "closed";
  message: string;
  guest?: { name: string; seatNumber: number | null };
};

export default function ArrivePage() {
  const { slug } = useParams<{ slug: string }>();
  const [event, setEvent] = useState<PublicEvent | null>(null);
  const [loadingEvent, setLoadingEvent] = useState(true);
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  useEffect(() => {
    const fromLink = new URLSearchParams(window.location.search).get("code");
    if (fromLink) setCode(fromLink.toUpperCase());
    fetch(`/api/invite/${slug}/event`)
      .then((r) => r.json())
      .then((d) => setEvent(d.event ?? null))
      .catch(() => setEvent(null))
      .finally(() => setLoadingEvent(false));
  }, [slug]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!code.trim()) return;
    setBusy(true);
    setResult(null);
    try {
      const res = await fetch("/api/arrive", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug, code }),
      });
      const data = await res.json().catch(() => ({}));
      setResult(data.status ? data : { status: "invalid", message: data.error || "Please try again." });
    } catch {
      setResult({ status: "invalid", message: "No connection. Please try again or see an usher." });
    } finally {
      setBusy(false);
    }
  };

  const primary = event?.primaryColor ?? "#0A2810";
  const gold = event?.secondaryColor ?? "#B8860B";

  if (loadingEvent) {
    return <div className="min-h-screen flex items-center justify-center bg-stone-50"><Loader2 className="h-8 w-8 animate-spin text-stone-400" /></div>;
  }
  if (!event) {
    return <div className="min-h-screen flex items-center justify-center bg-stone-50 p-6 text-center text-stone-600">This check-in link isn't active.</div>;
  }

  const ok = result?.status === "success" || result?.status === "already_checked_in";

  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-5" style={{ background: primary }}>
      <div className="w-full max-w-md rounded-3xl bg-white p-7 shadow-2xl">
        <div className="text-center">
          <p className="text-xs font-bold tracking-[0.3em]" style={{ color: gold }}>WELCOME TO</p>
          <h1 className="mt-2 text-2xl font-bold text-stone-900">{event.name}</h1>
          <p className="mt-1 text-sm text-stone-500">{event.venue}</p>
        </div>

        {ok && result?.guest ? (
          <div className="mt-8 text-center">
            <CheckCircle className="mx-auto h-20 w-20 text-emerald-500" />
            <p className="mt-4 text-2xl font-bold text-stone-900">{result.guest.name}</p>
            <p className="mt-1 text-stone-600">{result.message}</p>
            {result.guest.seatNumber ? (
              <div className="mt-6 inline-block rounded-2xl px-8 py-4 text-white" style={{ background: primary }}>
                <p className="text-xs font-bold tracking-[0.3em]" style={{ color: gold }}>YOUR SEAT</p>
                <p className="text-5xl font-bold">{result.guest.seatNumber}</p>
              </div>
            ) : null}
            <p className="mt-6 text-xs text-stone-400">Show this screen to an usher if asked.</p>
          </div>
        ) : (
          <form onSubmit={submit} className="mt-8 space-y-4">
            <label className="block">
              <span className="text-sm font-medium text-stone-700">Your check-in code</span>
              <input
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                placeholder="INV-XXXXXXXX"
                autoCapitalize="characters"
                autoComplete="off"
                className="mt-1 w-full rounded-2xl border border-stone-300 px-4 py-4 text-center font-mono text-xl tracking-widest text-stone-900 outline-none focus:ring-2"
              />
              <span className="mt-1 block text-xs text-stone-500">It's on your admission card and in your confirmation email.</span>
            </label>
            <button
              type="submit"
              disabled={busy || !code.trim()}
              className="flex w-full items-center justify-center gap-2 rounded-2xl py-4 text-base font-bold text-white disabled:opacity-60"
              style={{ background: primary }}
            >
              {busy ? <Loader2 className="h-5 w-5 animate-spin" /> : <QrCode className="h-5 w-5" />} Check me in
            </button>
            {result && (
              <div className={`flex items-start gap-2 rounded-2xl p-4 text-sm ${result.status === "too_early" || result.status === "closed" ? "bg-amber-50 text-amber-800" : "bg-red-50 text-red-700"}`}>
                {result.status === "too_early" || result.status === "closed" ? <AlertCircle className="h-5 w-5 shrink-0" /> : <XCircle className="h-5 w-5 shrink-0" />}
                <span>{result.message}</span>
              </div>
            )}
          </form>
        )}
      </div>
    </main>
  );
}
