# Invitely

Event invitation platform: Next.js 14 · Clerk · Prisma · Supabase (Postgres) · Cloudinary.

The app lives in [`invitely/`](./invitely). **Start with [`invitely/SETUP.md`](./invitely/SETUP.md).**
